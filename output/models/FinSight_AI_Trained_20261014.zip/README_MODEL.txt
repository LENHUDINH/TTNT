FINSIGHT AI — MODEL ĐÃ HUẤN LUYỆN, 14/10/2026

Gồm adapter QLoRA Qwen3-1.7B và candidate ML tài chính.
Không gồm trọng số model nền gần 1 GB, venv hoặc cấu hình .env riêng tư.
Model nền và revision nằm trong chat/base-model.json; tải đúng revision
và kiểm tra SHA-256 trong base-model-integrity.json.
Adapter được huấn luyện bằng MLX trên Apple Silicon, không phải file exe.
Dùng adapter với thư viện/phiên bản trong training-requirements.lock.

Phải dùng tài liệu tham chiếu knowledge.py và serving validator của FinSight.
Adapter đứng riêng đã bị từ chối sau kiểm tra ngữ nghĩa. Bản adapter kết hợp
tra cứu đã được đánh giá riêng và đang chạy qua app; xem grounded-evaluation.
Các corpus là dữ liệu tổng hợp nhỏ, không chứng minh độ chính xác thực tế.
Không dùng model để tự chuyển tiền hoặc kết luận gian lận.

ML tài chính: chỉ load joblib do người vận hành tin cậy và kiểm tra checksum
bằng training.artifacts verify của dự án; dependency AI nằm trong
ai-service/requirements.txt. Hướng dẫn tái lập nằm trong report/.
Các đường dẫn tuyệt đối trong config/provenance là vị trí gốc lúc train,
cần trỏ tới thư mục model của máy mới khi chạy lại.

CHECKSUMS.json chứa SHA-256 từng file. Gói không có dữ liệu tài khoản thật,
chat cá nhân, mật khẩu DB hoặc API key.
